package com.demo.spring;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class RabbitTestRunner implements CommandLineRunner{

	@Autowired
	RabbitTemplate rt;
	
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		rt.convertAndSend("testQueue", "Hi how are you doing");
		System.out.println("message send");
		
		String message = (String)rt.receiveAndConvert("testQueue");
		System.out.println("Message from Queue::"+message);
	}

}
