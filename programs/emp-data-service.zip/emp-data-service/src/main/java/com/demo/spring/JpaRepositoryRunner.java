package com.demo.spring;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.demo.spring.entity.Emp;

@Component
public class JpaRepositoryRunner implements CommandLineRunner {

	@Autowired
	EmpRepository empRepo;
	
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		empRepo.findAll().stream().forEach(System.out::println);
		
		Optional<Emp> optional = empRepo.findById(106);
		if(optional.isPresent()) {
			System.out.println("value:::"+optional.get());
		}else {
			System.out.println("Emp not find");
		}
	}

}
