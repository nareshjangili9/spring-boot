package com.demo.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class RestClientRunner implements CommandLineRunner {

	@Autowired
	RestTemplate restTemplate;
	
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("init");
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		HttpEntity entity = new HttpEntity(headers);
		ResponseEntity<Object> responseEntity = restTemplate.exchange("http://localhost:8181/emp/find/108",HttpMethod.GET, entity, Object.class);
//		ResponseEntity responseEntity = restTemplate.getForEntity("http://localhost:8181/emp/findAll", ResponseEntity.class);
		System.out.println("response:::"+responseEntity.getBody().toString());
	}

}
