package com.demo.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class RestClientPost implements CommandLineRunner {

	@Autowired
	RestTemplate restTem;
	
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		HttpEntity entity = new HttpEntity(headers);
		
		ResponseEntity<Object> responseEntity = restTem.exchange("http://localhost:8181/emp/find/108",HttpMethod.POST, entity, Object.class);
	}

}
