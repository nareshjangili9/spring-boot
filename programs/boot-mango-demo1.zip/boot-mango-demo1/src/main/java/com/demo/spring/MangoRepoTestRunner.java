package com.demo.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.demo.spring.entity.Emp;

@Component
public class MangoRepoTestRunner implements CommandLineRunner {

	@Autowired
	EmpMongoRepository repo;
	
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		repo.insert(new Emp(110, "Govind", "Hyd", 80000));
		System.out.println("Inserted::::");
		System.out.println("Below all records:::");
		repo.findAll().stream().forEach(System.out::println);
//		repo.findAll().stream().forEach(System.out::println);
	}

}
