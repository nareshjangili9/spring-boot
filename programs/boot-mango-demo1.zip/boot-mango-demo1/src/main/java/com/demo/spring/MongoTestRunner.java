package com.demo.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import com.demo.spring.entity.Emp;

@Component
public class MongoTestRunner implements CommandLineRunner {

	@Autowired
	MongoTemplate mongoTemplate;

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		mongoTemplate.findAll(Emp.class).stream().forEach(System.out::println);

		System.out.println("Condition::::");
		mongoTemplate.find(new Query(Criteria.where("salary").gt(40000)), Emp.class).stream()
				.forEach(System.out::println);
	}

}
