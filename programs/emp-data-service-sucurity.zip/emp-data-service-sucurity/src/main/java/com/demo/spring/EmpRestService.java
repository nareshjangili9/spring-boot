package com.demo.spring;

import java.util.List;
import java.util.Optional;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.demo.spring.entity.Emp;

@RestController
public class EmpRestService {

	@RequestMapping(path = "/info", method = RequestMethod.GET, produces = MediaType.TEXT_PLAIN_VALUE)
	public String info() {
		return "This is first Rest service";
	}

	@Autowired
	EmpRepository empRepo;

	@RequestMapping(path = "/emp/find2/{empId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_XML_VALUE)
	public Optional<Emp> test(@PathVariable("empId") int empId) {
		// TODO Auto-generated method stub
		empRepo.findAll().stream().forEach(System.out::println);

		Optional<Emp> optional = empRepo.findById(empId);
		if (optional.isPresent()) {
			System.out.println("value:::" + optional.get());
		} else {
			System.out.println("Emp not find");
		}
		return optional;
	}

	@RequestMapping(path = "/emp/findAll", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Emp>> findAll() {
		// TODO Auto-generated method stub
//		empRepo.findAll().stream().forEach(System.out::println);
		return ResponseEntity.ok(empRepo.findAll());
	}

//	@RequestMapping(path="/emp/find1/{empId}", method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	@GetMapping(path = "/emp/find/{empId}", produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	public ResponseEntity test1(@PathVariable("empId") int empId) {
		// TODO Auto-generated method stub
		empRepo.findAll().stream().forEach(System.out::println);

		Optional<Emp> optional = empRepo.findById(empId);
		if (optional.isPresent()) {
			return ResponseEntity.ok(optional.get());
		} else {
			return ResponseEntity.ok("Emp not found");
		}

	}

	@PostMapping(path = "/emp/saveForm", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE, produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity<String> saveDormData(@RequestParam("id") int id, @RequestParam("name") String name,
			@RequestParam("city") String city, @RequestParam("sal") double sal) {
		if(empRepo.existsById(id)) {
			return ResponseEntity.ok("Emp already exists");
		}else {
			Emp emp1 = new Emp();
			emp1.setEmpid(id);
			emp1.setCity(city);
			emp1.setName(name);
			emp1.setSalary(sal);
			empRepo.save(emp1);
			return ResponseEntity.ok("Emp Saved Successfully");
		}
	}
	@PostMapping(path = "/emp/save", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity<String> saveJsonData(@RequestBody Emp emp) {
		if(empRepo.existsById(emp.getEmpid())) {
			return ResponseEntity.ok("Emp already exists");
		}else {
			empRepo.save(emp);
			return ResponseEntity.ok("Emp Saved Successfully");
		}
	}
	
	@PutMapping(path = "/emp/update", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity<String> update(@RequestBody Emp emp) {
			empRepo.save(emp);
			return ResponseEntity.ok("Emp Updated Successfully");
	}
	
	@DeleteMapping(path = "/emp/delete/{empId}", produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity delete(@PathVariable("empId") int empId) {
		// TODO Auto-generated method stub
		empRepo.deleteById(empId);
		return ResponseEntity.ok("Deleted");
	}
}
