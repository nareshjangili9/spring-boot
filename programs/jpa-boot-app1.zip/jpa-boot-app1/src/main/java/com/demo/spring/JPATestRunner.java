package com.demo.spring;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.demo.spring.entity.Emp;

@Component
@Transactional
public class JPATestRunner implements CommandLineRunner {

//	@Autowired
	@PersistenceContext
	EntityManager em;
	
	
	
	
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
//		Emp entity = new Emp(1112, "Nareh", "Hyderabad", 2);
//		em.persist(entity);
		System.out.println("inserted successfully");
		Emp emp = em.find(Emp.class, 108);
		System.out.println("Retreived emp:"+emp);
		
		Query query = em.createQuery("select e FROM Emp e");
		query.getResultList().stream().forEach(System.out::println);;
	}

}
