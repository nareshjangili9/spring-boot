package com.optum.lamda;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class LamdaExp {
	public static void main(String[] args) {
		Thread th = new Thread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				System.out.println("runnable method");
			}
		});
		th.start();
		Thread th2 = new Thread(()-> System.out.println("Lamba expression exmaple"));
		th2.start();
		
		List<String> list = Arrays.asList("john","smith","govind","naresh","vijay","nagesh");
		list.stream().forEach(System.out::println);
		System.out.println(list.stream().count());
		list.stream().filter(s->s.startsWith("n")).forEach(System.out::println);
		
		list.stream().filter(s->s.startsWith("n")).collect(Collectors.toList());
		
	}
	

}
