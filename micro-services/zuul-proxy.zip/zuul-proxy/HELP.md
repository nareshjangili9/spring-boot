# Getting Started

### Guides
The following guides illustrates how to use certain features concretely:

* [Routing and Filtering](https://spring.io/guides/gs/routing-and-filtering/)

