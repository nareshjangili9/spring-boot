package com.demo.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class HrService {

	@Autowired
	RestTemplate restTemplate;

	@HystrixCommand(fallbackMethod="handleGetEmpDetails")
	public ResponseEntity getEmpDetails(int id) {

		// TODO Auto-generated method stub
		System.out.println("init");
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		HttpEntity entity = new HttpEntity(headers);
		ResponseEntity<Object> responseEntity = restTemplate.exchange("http://emp-service/emp/find/" + id,
				HttpMethod.GET, entity, Object.class);
//		ResponseEntity responseEntity = restTemplate.getForEntity("http://localhost:8181/emp/findAll", ResponseEntity.class);
		System.out.println("response:::getEmpDetails");
		return responseEntity;

	}

	public ResponseEntity listAllEmp() {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		HttpEntity entity = new HttpEntity(headers);
		ResponseEntity<Object> responseEntity = restTemplate.exchange("http://emp-service/emp/findAll", HttpMethod.GET,
				entity, Object.class);
//				ResponseEntity responseEntity = restTemplate.getForEntity("http://localhost:8181/emp/findAll", ResponseEntity.class);
		System.out.println("response:::");
		return responseEntity;

	}
	
	public ResponseEntity handleGetEmpDetails(int id) {
		return ResponseEntity.ok("Service is down::::");
	}
}
